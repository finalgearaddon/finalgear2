#V 2.0.7
import xbmc , xbmcaddon , xbmcgui , xbmcplugin , requests , urllib , urllib2 , json , os , re , sys , datetime , urlresolver , random , liveresolver , base64 , pyxbmct
from resources . lib . common_addon import Addon
from HTMLParser import HTMLParser
from metahandler import metahandlers
import nanscrapers
if 64 - 64: i11iIiiIii
if 65 - 65: Vev / iIii1I11I1II1 % VeeeeeeeVV - i1IIi
eevVVevev = 'plugin.video.finalgear'
ee = Addon ( eevVVevev , sys . argv )
i1iII1IiiIiI1 = xbmcaddon . Addon ( id = eevVVevev )
iIiiiI1IiI1I1 = xbmcaddon . Addon ( ) . getAddonInfo
eevVeVeVVevev = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + eevVVevev , 'fanart.png' ) )
I11i = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + eevVVevev , 'fanart.png' ) )
VevV = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + eevVVevev , 'icon.png' ) )
Ve = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + eevVVevev + '/resources/art' , 'next.png' ) )
I1ii11iIi11i = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + eevVVevev + '/resources' , 'rd.txt' ) )
I1IiI = 'http://pastebin.com/raw/U7NtCR5i'
eevVVV = i1iII1IiiIiI1 . getSetting ( 'password' )
iIiiiI = i1iII1IiiIiI1 . getSetting ( 'enable_meta' )
Iii1ii1II11i = 'http://'
iI111iI = xbmc . translatePath ( 'special://home/userdata/addon_data/' + eevVVevev )
IiII = xbmc . translatePath ( os . path . join ( 'special://home/userdata/Database' , 'Evolve.db' ) )
iI1Ii11111iIi = open ( IiII , 'a' )
iI1Ii11111iIi . close ( )
if 41 - 41: I1II1
def VeeevVVeveVV ( ) :
 if not os . path . exists ( iI111iI ) :
  os . mkdir ( iI111iI )
  if 86 - 86: eVeve
  if 12 - 12: VVVeveeve / eeveVev + i111I * VevVeeveVeve . II1iI . i1iIii1Ii1II
  if 1 - 1: VevVeeeevev
  if 87 - 87: i1IIi11111i / I11i1i11i1I % eeIiII1I1i1i1ii / eVVVeeveevV + VeVeeev % eVVee
 I1IiIiiIII = iI11 ( I1IiI )
 iII111ii = re . compile ( '<item>(.+?)</item>' ) . findall ( I1IiIiiIII )
 for i1iIIi1 in iII111ii :
  ii11iIi1I = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( i1iIIi1 )
  for iI111I11I1I1 , VVeeVevVVee , iIii1 , eevVeVeVVevev in ii11iIi1I :
   eVVeVev ( iI111I11I1I1 , VVeeVevVVee , 1 , iIii1 , eevVeVeVVevev )
   if 59 - 59: I11i1i11i1I * i11iIiiIii + I11i1i11i1I + eVVee * eeveVev
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 75 - 75: i1IIi - eeveVev / eVeve . VevVeeeevev
def iiIiIIi ( name , url , iconimage , fanart ) :
 eVVeVev ( '[B][COLOR red]MOVIE SEARCH[/COLOR][/B]' , 'http://evolverepo.net/EvolveMenus/Movies/Search/Search.txt' , 5 , 'http://i.imgur.com/Qlc3Efe.png' , I11i )
 eVVeVev ( '[B][COLOR yellow]UK CINEMA RELEASE DATES[/COLOR][/B]' , 'http://www.empireonline.com/movies/features/upcoming-movies/' , 34 , 'http://i.imgur.com/1ImmOS4.png' , I11i )
 eeVeeevV = VeeVev ( name )
 i1iII1IiiIiI1 . setSetting ( 'movie' , eeVeeevV )
 I1IiIiiIII = iI11 ( url )
 iII111ii = re . compile ( '<item>(.+?)</item>' ) . findall ( I1IiIiiIII )
 for i1iIIi1 in iII111ii :
  ii11iIi1I = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( i1iIIi1 )
  for name , url , iconimage , fanart in ii11iIi1I :
   II11iiii1Ii ( name , url , iconimage , fanart , i1iIIi1 )
   if 70 - 70: i1iIii1Ii1II / iIii1I11I1II1 % eVVee % i11iIiiIii . eVeve
def VeveevVe ( name , url , iconimage , fanarts ) :
 eVVeVev ( '[B][COLOR blue]TV SEARCH[/COLOR][/B]' , 'http://evolverepo.net/anewEvolvemenu/search.xml' , 33 , 'http://i.imgur.com/gLWo9QO.png' , fanarts )
 eVVeVev ( '[B][COLOR yellow]TV SCHEDULE[/COLOR][/B]' , 'http://www.tvwise.co.uk/uk-premiere-dates/' , 32 , 'http://i.imgur.com/Pq53Nxh.png' , fanarts )
 eVVeVev ( '[B][COLOR blue]Latest[/COLOR] [COLOR white]Episodes[/COLOR][/B]' , 'http://www.watchepisodes4.com' , 28 , 'http://i.imgur.com/PmLtUtH.png' , fanarts )
 eVVeVev ( '[B][COLOR blue]Popular[/COLOR] [COLOR white]Shows[/COLOR][/B]' , 'http://www.watchepisodes4.com/home/popular-series' , 29 , 'http://i.imgur.com/SHXfj1a.png' , fanarts )
 eVVeVev ( '[B][COLOR blue]New[/COLOR] [COLOR white]Shows[/COLOR][/B]' , 'http://www.watchepisodes4.com/home/new-series' , 30 , 'http://i.imgur.com/roVYGM8.png' , fanarts )
 eeVeeevV = VeeVev ( name )
 i1iII1IiiIiI1 . setSetting ( 'tv' , eeVeeevV )
 I1IiIiiIII = iI11 ( url )
 iII111ii = re . compile ( '<item>(.+?)</item>' ) . findall ( I1IiIiiIII )
 for i1iIIi1 in iII111ii :
  ii11iIi1I = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( i1iIIi1 )
  for name , url , iconimage , eevVeVeVVevev in ii11iIi1I :
   II11iiii1Ii ( name , url , iconimage , eevVeVeVVevev , i1iIIi1 )
   if 78 - 78: iIii1I11I1II1 - I11i1i11i1I * eeveVev + VevVeeveVeve + eeIiII1I1i1i1ii + eeIiII1I1i1i1ii
def I11I11i1I ( name , url , iconimage , fanart ) :
 eeVeeevV = VeeVev ( name )
 i1iII1IiiIiI1 . setSetting ( 'tv' , eeVeeevV )
 I1IiIiiIII = iI11 ( url )
 ii11i1iIII ( I1IiIiiIII )
 if '<message>' in I1IiIiiIII :
  Iii1ii1II11i = re . compile ( '<message>(.+?)</message>' ) . findall ( I1IiIiiIII ) [ 0 ]
  Ii1I ( Iii1ii1II11i , eeVeeevV )
 if '<intro>' in I1IiIiiIII :
  Veeveev = re . compile ( '<intro>(.+?)</intro>' ) . findall ( I1IiIiiIII ) [ 0 ]
  III1ii1iII ( Veeveev )
 if 'XXX>yes</XXX' in I1IiIiiIII : eeeveeeeeVev ( I1IiIiiIII )
 iII111ii = re . compile ( '<item>(.+?)</item>' ) . findall ( I1IiIiiIII )
 for i1iIIi1 in iII111ii :
  II11iiii1Ii ( name , url , iconimage , fanart , i1iIIi1 )
  if 19 - 19: i1IIi11111i + eVVee
def II11iiii1Ii ( name , url , iconimage , fanart , item ) :
 try :
  if '<sportsdevil>' in item : eee ( name , url , iconimage , fanart , item )
  elif '<iplayer>' in item : ii1I1i1I ( name , url , iconimage , fanart , item )
  elif '<folder>' in item : VVeeevVev ( name , url , iconimage , fanart , item )
  elif '<iptv>' in item : iiiIi1i1I ( name , url , iconimage , fanart , item )
  elif '<image>' in item : eVVeveveVV ( name , url , iconimage , fanart , item )
  elif '<text>' in item : VeVe ( name , url , iconimage , fanart , item )
  elif '<scraper>' in item : iI ( name , url , iconimage , fanart , item )
  elif '<lbscraper>' in item : eevevV ( name , url , iconimage , fanart , item )
  elif '<redirect>' in item : VVVevVVVevevee ( name , url , iconimage , fanart , item )
  elif '<oktitle>' in item : Iii111II ( name , url , iconimage , fanart , item )
  elif '<nan>' in item : iiii11I ( name , url , iconimage , fanart , item )
  else : VeeevVVeveVVii11i1 ( name , url , iconimage , fanart , item )
 except : pass
 if 29 - 29: II1iI % eVeve + eVVee / VevVeeveVeve + VevVeeeevev * VevVeeveVeve
def ii1I1i1I ( name , url , iconimage , fanart , item ) :
 url = re . compile ( '<iplayer>(.+?)</iplayer>' ) . findall ( item ) [ 0 ]
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 url = 'plugin://plugin.video.iplayerwww/?url=%s&mode=202&name=%s&iconimage=%s&description=&subtitles_url=&logged_in=False' % ( url , name , iconimage )
 i1I1iI ( name , url , 16 , iconimage , fanart )
 if 93 - 93: iIii1I11I1II1 % i1iIii1Ii1II * i1IIi
def iiii11I ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 Ii11Ii1I = re . compile ( '<meta>(.+?)</meta>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 VeveveV = re . compile ( '<nan>(.+?)</nan>' ) . findall ( item ) [ 0 ]
 I11i1I1I = re . compile ( '<imdb>(.+?)</imdb>' ) . findall ( item ) [ 0 ]
 if VeveveV == 'movie' :
  I11i1I1I = I11i1I1I + '<>movie'
 elif VeveveV == 'tvshow' :
  eVevVe = re . compile ( '<showname>(.+?)</showname>' ) . findall ( item ) [ 0 ]
  eVVeeevVe = re . compile ( '<season>(.+?)</season>' ) . findall ( item ) [ 0 ]
  eevevVVevevVeV = re . compile ( '<episode>(.+?)</episode>' ) . findall ( item ) [ 0 ]
  VVVVevVVeVevVev = re . compile ( '<showyear>(.+?)</showyear>' ) . findall ( item ) [ 0 ]
  VevVeeveveveeVevev = re . compile ( '<episodeyear>(.+?)</episodeyear>' ) . findall ( item ) [ 0 ]
  I11i1I1I = I11i1I1I + '<>' + eVevVe + '<>' + eVVeeevVe + '<>' + eevevVVevevVeV + '<>' + VVVVevVVeVevVev + '<>' + VevVeeveveveeVevev
  VeveveV = "tvep"
 eVev ( name , I11i1I1I , 19 , iconimage , 1 , VeveveV , isFolder = True )
 if 45 - 45: i11iIiiIii * I1II1 % iIii1I11I1II1 + II1iI - I11i1i11i1I
def iIi1iIiii111 ( name , imdb , iconimage , fanart ) :
 I1ii11iIi11i = ''
 iIIIi1 = name
 eeVeeevV = VeeVev ( name )
 i1iII1IiiIiI1 . setSetting ( 'tv' , eeVeeevV )
 if 'movie' in imdb :
  imdb = imdb . split ( '<>' ) [ 0 ]
  iiII1i1 = [ ]
  eeveveVVeve = [ ]
  VVVevevV = name . partition ( '(' )
  VVeVVeveeeveeV = VVVevevV [ 0 ]
  VVeVVeveeeveeV = VeeVev ( VVeVVeveeeveeV )
  VeveevVevevVeeveev = VVVevevV [ 2 ] . partition ( ')' ) [ 0 ]
  VevevVeveVVevevVevev = nanscrapers . scrape_movie ( VVeVVeveeeveeV , VeveevVevevVeeveev , imdb , timeout = 800 )
 else :
  eVevVe = imdb . split ( '<>' ) [ 1 ]
  i1 = imdb . split ( '<>' ) [ 0 ]
  eVVeeevVe = imdb . split ( '<>' ) [ 2 ]
  eevevVVevevVeV = imdb . split ( '<>' ) [ 3 ]
  VVVVevVVeVevVev = imdb . split ( '<>' ) [ 4 ]
  VevVeeveveveeVevev = imdb . split ( '<>' ) [ 5 ]
  VevevVeveVVevevVevev = nanscrapers . scrape_episode ( eVevVe , VVVVevVVeVevVev , VevVeeveveveeVevev , eVVeeevVe , eevevVVevevVeV , i1 , None )
 Veevev = 1
 for i1i in list ( VevevVeveVVevevVevev ( ) ) :
  for iiI111I1iIiI in i1i :
   if urlresolver . HostedMediaFile ( iiI111I1iIiI [ 'url' ] ) . valid_url ( ) :
    I1ii11iIi11i = II ( iiI111I1iIiI [ 'url' ] )
    name = "Link " + str ( Veevev ) + ' | ' + iiI111I1iIiI [ 'source' ] + I1ii11iIi11i
    Veevev = Veevev + 1
    Ii1I1IIii1II ( name , iiI111I1iIiI [ 'url' ] , 2 , iconimage , fanart , description = i1iII1IiiIiI1 . getSetting ( 'tv' ) )
    if 65 - 65: I11i1i11i1I . iIii1I11I1II1 / Vev - I11i1i11i1I
def iI ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<scraper>(.+?)</scraper>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 eVVeVev ( name , url , 18 , iconimage , fanart )
 if 21 - 21: eVeve * iIii1I11I1II1
def eeeeeVeeeveee ( name , url , iconimage , fanart ) :
 I1I1IiI1 = url
 if I1I1IiI1 == 'latestmovies' :
  III1iII1I1ii = 15
  eVVeev = MOVIESINDEXER ( )
  eeevevVeveveV = re . compile ( '<item>(.+?)</item>' ) . findall ( eVVeev )
  for i1iIIi1 in eeevevVeveveV :
   ii11iIi1I = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( i1iIIi1 )
   iIiIIIi = len ( eeevevVeveveV )
   for name , url , iconimage , fanart in ii11iIi1I :
    if '<meta>' in i1iIIi1 :
     eeeevevVVVeeV = re . compile ( '<meta>(.+?)</meta>' ) . findall ( i1iIIi1 ) [ 0 ]
     eVev ( name , url , III1iII1I1ii , iconimage , iIiIIIi , eeeevevVVVeeV , isFolder = False )
    else : Ii1I1IIii1II ( name , url , 15 , iconimage , fanart )
    if 67 - 67: i1IIi11111i * i1iIii1Ii1II * II1iI + VevVeeeevev / i1IIi
    if 11 - 11: I11i1i11i1I + eeIiII1I1i1i1ii - eVVee * i1iIii1Ii1II % i11iIiiIii - VeVeeev
def eeveV ( name , url , iconimage , fanarts ) :
 I1IiIiiIII = IIiIi1iI ( 'http://www.watchepisodes4.com' )
 i1IiiiI1iI = re . compile ( '<a title=".+?" .+? style="background-image: url(.+?)"></a>.+?<div class="hb-right">.+?<a title=".+?" href="(.+?)" class="episode">(.+?)</a>' , re . DOTALL ) . findall ( I1IiIiiIII )
 for iconimage , url , name in i1IiiiI1iI :
  iconimage = iconimage . replace ( "('" , "" ) . replace ( "')" , "" )
  name = name . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  name = name . split ( '  ' ) [ 0 ]
  eVVeVev ( name , url , 24 , iconimage , iconimage )
  if 49 - 49: I11i1i11i1I / eeveVev . I1II1
def eeVVeeeeee ( name , url , iconimage , fanart ) :
 I1IiIiiIII = IIiIi1iI ( url )
 i1IiiiI1iI = re . compile ( '<div class="cb-first">.+?<a href="(.+?)" class="c-image"><img alt=".+?" title="(.+?)" src="(.+?)"></a>' , re . DOTALL ) . findall ( I1IiIiiIII )
 for url , name , iconimage in i1IiiiI1iI :
  name = name . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  eVVeVev ( name , url , 31 , iconimage , iconimage )
  if 1 - 1: VVVeveeve / VevVeeveVeve % eeIiII1I1i1i1ii * eVVVeeveevV . i11iIiiIii
def III1Iiii1I11 ( name , url , iconimage , fanart ) :
 I1IiIiiIII = IIiIi1iI ( url )
 i1IiiiI1iI = re . compile ( '<div class="cb-first">.+?<a href="(.+?)" class="c-image"><img alt=".+?" title="(.+?)" src="(.+?)"></a>' , re . DOTALL ) . findall ( I1IiIiiIII )
 for url , name , iconimage in i1IiiiI1iI :
  name = name . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  eVVeVev ( name , url , 31 , iconimage , iconimage )
  if 9 - 9: II1iI / VVVeveeve - eVeve / VeeeeeeeVV / iIii1I11I1II1 - VevVeeveVeve
def eeveveeeVevVe ( name , url , iconimage , fanart ) :
 I1IiIiiIII = eevVevVVVevVee ( url )
 iiIiI = re . compile ( '<div class="std-cts">.+?<div class="sdt-content tnContent">.+?<h2>(.+?)</h2>' , re . DOTALL ) . findall ( I1IiIiiIII ) [ 0 ] . replace ( ' Episodes' , '' ) . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
 iII111ii = re . compile ( '<a title=".+?" href="(.+?)">.+?<div class="season">(.+?) </div>.+?<div class="episode">(.+?)</div>.+?<div class="e-name">(.+?)</div>' , re . DOTALL ) . findall ( I1IiIiiIII )
 for url , eVVeeevVe , eevevVVevevVeV , I1 in iII111ii :
  I1 = I1 . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  if '</div>' in name : name = 'TBA'
  eVVeVev ( '%s ' % iiIiI + '(%s ' % eVVeeevVe + '%s)' % eevevVVevevVeV , url , 24 , iconimage , iconimage )
  if 86 - 86: i111I - I11i1i11i1I - eeveVev * eeIiII1I1i1i1ii
def eeeeevVev ( name , url , iconimage , fanart ) :
 iIIIi1 = name
 I1IiIiiIII = eevVevVVVevVee ( url )
 eVVV = re . compile ( '<a target="_blank" href=".+?" data-episodeid=".+?" data-linkid=".+?" data-hostname=".+?" class="watch-button" data-actuallink="(.+?)">Watch Now!</a>' ) . findall ( I1IiIiiIII )
 Veevev = 1
 iiII1i1 = [ ]
 eeveveVVeve = [ ]
 for iIII1 in eVVV :
  I1ii11iIi11i = II ( iIII1 )
  if 'http' in iIII1 : eeve = iIII1 . split ( '/' ) [ 2 ] . split ( '.' ) [ 0 ]
  else : eeve = iIII1
  name = "Link " + str ( Veevev ) + ' | ' + eeve + I1ii11iIi11i
  if eeve != 'www' :
   Ii1I1IIii1II ( eeve , iIII1 , 2 , iconimage , fanart , description = '' )
   if 73 - 73: eVVVeeveevV * II1iI + eVeve . eVVee
def eeveVevevevevev ( name , url , iconimage , fanart ) :
 I1IiIiiIII = eevVevVVVevVee ( url )
 i1IiiiI1iI = re . compile ( '<td height="20">(.+?)</td>.+?<td>(.+?)</td>.+?<td><a href=".+?">(.+?)</a></td>.+?<td><a href=".+?">(.+?)</a></td>.+?</tr>' , re . DOTALL ) . findall ( I1IiIiiIII )
 for VVVVeeevVe , name , ii111iI1iIi1 , VVV in i1IiiiI1iI :
  name = name . replace ( "&#8217;" , "'" ) . replace ( '&amp;' , ' & ' )
  eVVeVev ( '[COLOR yellow]%s[/COLOR] - ' % ii111iI1iIi1 + '[COLOR blue]%s[/COLOR] ' % name + '- [COLOR white]%s[/COLOR]' % VVVVeeevVe , url , 28 , iconimage , fanart )
  if 68 - 68: I1II1 + i1IIi11111i
def I1I1I ( url ) :
 VeVVevevev = ''
 i1Ii11i1i = xbmc . Keyboard ( VeVVevevev , '[B][COLOR red]S[/COLOR][COLOR white]earch[/COLOR][/B] [B][COLOR red]E[/COLOR][COLOR white]volve[/COLOR][/B]' )
 i1Ii11i1i . doModal ( )
 if i1Ii11i1i . isConfirmed ( ) :
  VeVVevevev = i1Ii11i1i . getText ( ) . replace ( ' ' , '+' ) . replace ( '+and+' , '+%26+' )
 if len ( VeVVevevev ) > 1 :
  url = 'http://www.watchepisodes4.com/search/ajax_search?q=' + VeVVevevev
  I1IiIiiIII = eevVevVVVevVee ( url )
  ii11iIi1I = json . loads ( I1IiIiiIII )
  ii11iIi1I = ii11iIi1I [ 'series' ]
  for i1iIIi1 in ii11iIi1I :
   iI111I11I1I1 = i1iIIi1 [ 'value' ]
   eeveVVee = i1iIIi1 [ 'seo' ]
   url = 'http://www.watchepisodes4.com/' + eeveVVee
   iIii1 = 'http://www.watchepisodes4.com/movie_images/' + eeveVVee + '.jpg'
   eVVeVev ( iI111I11I1I1 , url , 31 , iIii1 , eevVeVeVVevev )
  VeVVevevev = VeVVevevev [ : - 1 ]
  I1IiIiiIII = iI11 ( 'http://evolverepo.net/anewEvolvemenu/search.xml' )
  eVeevevVeveeeveveev = re . compile ( '<link>(.+?)</link>' ) . findall ( I1IiIiiIII )
  for url in eVeevevVeveeeveveev :
   try :
    I1IiIiiIII = iI11 ( url )
    ii = re . compile ( '<item>(.+?)</item>' ) . findall ( I1IiIiiIII )
    for i1iIIi1 in ii :
     iII111ii = re . compile ( '<title>(.+?)</title>' ) . findall ( i1iIIi1 )
     for iIIIi1 in iII111ii :
      iIIIi1 = VeeVev ( iIIIi1 . upper ( ) )
      VeVVevevev = VeVVevevev . upper ( )
      if VeVVevevev in iIIIi1 :
       II11iiii1Ii ( iI111I11I1I1 , url , iIii1 , eevVeVeVVevev , i1iIIi1 )
   except : pass
   if 84 - 84: VevVeeveVeve % I1II1 . i11iIiiIii / eeveVev
   if 80 - 80: VeVeeev . i11iIiiIii - VevVeeveVeve
def iIiIIi1 ( name , url , iconimage , fanart ) :
 I1IiIiiIII = eevVevVVVevVee ( url )
 i1IiiiI1iI = re . compile ( '<h2 id=".+?">(.+?)</h2>.+?<p><span class="article__image article__image--undefined"><img src="(.+?)" alt=".+?"></span> </p>.+?<p><strong>(.+?)</strong>(.+?)<' , re . DOTALL ) . findall ( I1IiIiiIII )
 for iIIIi1 , iconimage , I1IIII1i , ii111iI1iIi1 in i1IiiiI1iI :
  name = name . replace ( "&#8217;" , "'" ) . replace ( '&amp;' , ' & ' )
  eVVeVev ( '[COLOR yellow]%s [/COLOR] ' % iIIIi1 + '[COLOR red]%s[/COLOR]' % I1IIII1i + '[COLOR white]%s[/COLOR]' % ii111iI1iIi1 , url , 35 , iconimage , fanart )
def I1I11i ( name , url , iconimage , fanart ) :
 I1IiIiiIII = iI11 ( 'http://evolverepo.net/EvolveMenus/Movies/EvolveLatest/mainmenu.xml' )
 i1IiiiI1iI = re . compile ( '<item>(.+?)</item>' ) . findall ( I1IiIiiIII )
 for i1iIIi1 in i1IiiiI1iI :
  II11iiii1Ii ( name , url , iconimage , fanart , i1iIIi1 )
  if 5 - 5: VeeeeeeeVV % i111I % i1iIii1Ii1II % eeIiII1I1i1i1ii
  if 7 - 7: I1II1 + VeeeeeeeVV . VeVeeev . eVVee - VevVeeveVeve
def eevevV ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<lbscraper>(.+?)</lbscraper>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 eVVeVev ( name , url , 10 , iconimage , fanart )
 if 26 - 26: VVVeveeve / eVVVeeveevV % iIii1I11I1II1 / eVVVeeveevV + i1IIi11111i
def eVVevVeveveVevVee ( name , url , iconimage , fanart ) :
 VevevVeveVVevevVevev = eVevVeevVeve ( name , url , iconimage )
 iII111ii = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( VevevVeveVVevevVevev )
 for i1iIIi1 in iII111ii :
  II11iiii1Ii ( name , url , iconimage , fanart , i1iIIi1 )
  if 99 - 99: i1iIii1Ii1II . eeIiII1I1i1i1ii + eVVee % i1iIii1Ii1II . i11iIiiIii % Vev
def eVevVeevVeve ( name , url , iconimage ) :
 I1I1IiI1 = url
 eVVevevV = ''
 if url == 'mamahd' :
  I1IiIiiIII = IIiIi1iI ( "http://mamahd.com" ) . replace ( '\n' , '' ) . replace ( '\t' , '' )
  VVVeeevVV = re . compile ( '<a href="(.+?)">.+?<img src="(.+?)"></div>.+?<div class="home cell">.+?<span>(.+?)</span>.+?<span>(.+?)</span>.+?</a>' ) . findall ( I1IiIiiIII )
  for url , iconimage , eVeveev , iI1Ii11iIiI1 in VVVeeevVV :
   eVVevevV = eVVevevV + '<item>\n<title>%s vs %s</title>\n<sportsdevil>%s</sportsdevil>\n<thumbnail>%s</thumbnail>\n<fanart>fanart</fanart>\n</item>\n\n' % ( eVeveev , iI1Ii11iIiI1 , url , iconimage )
  return eVVevevV
  if 86 - 86: i1iIii1Ii1II * VevVeeveVeve % i1IIi . I11i1i11i1I . i11iIiiIii
 elif url == 'cricfree' :
  I1IiIiiIII = IIiIi1iI ( "http://cricfree.sc/football-live-stream" )
  eVVeeevevVeveve = re . compile ( '<td><span class="sport-icon(.+?)</tr>' , re . DOTALL ) . findall ( I1IiIiiIII )
  for VevVevevVe in eVVeeevevVeveve :
   eeeeeeevVeveveve = re . compile ( '<td>(.+?)<br(.+?)</td>' ) . findall ( VevVevevVe )
   for VeV , ii111iI1iIi1 in eeeeeeevVeveveve :
    VeV = '[COLOR red]' + VeV + '[/COLOR]'
    ii111iI1iIi1 = ii111iI1iIi1 . replace ( '>' , '' )
   VVV = re . compile ( '<td class="matchtime" style="color:#545454;font-weight:bold;font-size: 9px">(.+?)</td>' ) . findall ( VevVevevVe ) [ 0 ]
   VVV = '[COLOR white](' + VVV + ')[/COLOR]'
   eeVevVevVeveeVVV = re . compile ( '<a style="text-decoration:none !important;color:#545454;" href="(.+?)" target="_blank">(.+?)</a></td>' ) . findall ( VevVevevVe )
   for url , eVVeevVeveve in eeVevVevVeveeVVV :
    url = url
    eVVeevVeveve = eVVeevVeveve
   eVVevevV = eVVevevV + '\n<item>\n<title>%s</title>\n<sportsdevil>%s</sportsdevil>\n' % ( VeV + ' ' + VVV + ' - ' + eVVeevVeveve , url )
   eVVevevV = eVVevevV + '<thumbnail>iconimage</thumbnail>\n<fanart>fanart</fanart>\n</item>\n'
  return eVVevevV
  if 8 - 8: eeveVev
 elif url == 'bigsports' :
  I1IiIiiIII = IIiIi1iI ( "http://www.bigsports.me/cat/4/football-live-stream.html" )
  VVVeeevVV = re . compile ( '<td>.+?<td>(.+?)\-(.+?)\-(.+?)</td>.+?<td>(.+?)\:(.+?)</td>.+?<td>Football</td>.+?<td><strong>(.+?)</strong></td>.+?<a target=.+? href=(.+?) class=.+?' , re . DOTALL ) . findall ( I1IiIiiIII )
  for VeV , ii1111iII , iiiiI , eeeVeevVVVeeev , VVeV , name , url in VVVeeevVV :
   if not '</td>' in VeV :
    url = url . replace ( '"' , '' )
    ii111iI1iIi1 = VeV + ' ' + ii1111iII + ' ' + iiiiI
    VVV = eeeVeevVVVeeev + ':' + VVeV
    ii111iI1iIi1 = '[COLOR red]' + ii111iI1iIi1 + '[/COLOR]'
    VVV = '[COLOR white](' + VVV + ')[/COLOR]'
    eVVevevV = eVVevevV + '\n<item>\n<title>%s</title>\n<sportsdevil>%s</sportsdevil>\n' % ( ii111iI1iIi1 + ' ' + VVV + ' ' + name , url )
    eVVevevV = eVVevevV + '<thumbnail>iconimage</thumbnail>\n<fanart>fanart</fanart>\n</item>\n'
  return eVVevevV
  if 89 - 89: VevVeeveVeve + eeveVev * i1IIi11111i * I11i1i11i1I
def Iii111II ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iiIiI1i1 = re . compile ( '<oktitle>(.+?)</oktitle>' ) . findall ( item ) [ 0 ]
 eVevVeveveVVeeeV = re . compile ( '<line1>(.+?)</line1>' ) . findall ( item ) [ 0 ]
 IiIi11iI = re . compile ( '<line2>(.+?)</line2>' ) . findall ( item ) [ 0 ]
 VeevVevevVevevev = re . compile ( '<line3>(.+?)</line3>' ) . findall ( item ) [ 0 ]
 i11I1IiII1i1i = '##' + iiIiI1i1 + '#' + eVevVeveveVVeeeV + '#' + IiIi11iI + '#' + VeevVevevVevevev + '##'
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 i1I1iI ( name , i11I1IiII1i1i , 17 , iconimage , fanart )
 if 95 - 95: i11iIiiIii
def iI1111iiii ( name , url ) :
 VeevVV = re . compile ( '##(.+?)##' ) . findall ( url ) [ 0 ] . split ( '#' )
 VevVeeVeeve = xbmcgui . Dialog ( )
 VevVeeVeeve . ok ( VeevVV [ 0 ] , VeevVV [ 1 ] , VeevVV [ 2 ] , VeevVV [ 3 ] )
 if 29 - 29: eVeve % eVeve
def VVVevVVVevevee ( name , url , iconimage , fanart , item ) :
 url = re . compile ( '<redirect>(.+?)</redirect>' ) . findall ( item ) [ 0 ]
 I11I11i1I ( 'name' , url , 'iconimage' , 'fanart' )
 if 94 - 94: iIii1I11I1II1 / VVVeveeve % eeIiII1I1i1i1ii * eeIiII1I1i1i1ii * I1II1
def VeVe ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 i11I1IiII1i1i = re . compile ( '<text>(.+?)</text>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 i1I1iI ( name , i11I1IiII1i1i , 9 , iconimage , fanart )
 if 29 - 29: eeveVev + i111I / VevVeeveVeve / VevVeeeevev * iIii1I11I1II1
def VevVV ( name , url ) :
 ii1iI1I11I = eevVevVVVevVee ( url )
 II1iIVeveeveevevVVevevevev ( name , ii1iI1I11I )
 if 1 - 1: eVVee . eVVee / i111I - VeVeeev
def eVVeveveVV ( name , url , iconimage , fanart , item ) :
 eeeV = re . compile ( '<image>(.+?)</image>' ) . findall ( item )
 if len ( eeeV ) == 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  i1I1i111Ii = re . compile ( '<image>(.+?)</image>' ) . findall ( item ) [ 0 ]
  fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
  i1I1iI ( name , i1I1i111Ii , 7 , iconimage , fanart )
 elif len ( eeeV ) > 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
  eeei1i1iI1iiiI = ''
  for i1I1i111Ii in eeeV : eeei1i1iI1iiiI = eeei1i1iI1iiiI + '<image>' + i1I1i111Ii + '</image>'
  VeeeveVeeeev = iI111iI
  name = VeeVev ( name )
  eVVVeeevev = os . path . join ( os . path . join ( VeeeveVeeeev , '' ) , name + '.txt' )
  if not os . path . exists ( eVVVeeevev ) : file ( eVVVeeevev , 'w' ) . close ( )
  iiIiIIIiiI = open ( eVVVeeevev , "w" )
  iiIiIIIiiI . write ( eeei1i1iI1iiiI )
  iiIiIIIiiI . close ( )
  i1I1iI ( name , 'image' , 8 , iconimage , fanart )
  if 12 - 12: Vev - VevVeeveVeve
def iiiIi1i1I ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<iptv>(.+?)</iptv>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 eVVeVev ( name , url , 6 , iconimage , fanart )
 if 81 - 81: i111I - i111I . eeIiII1I1i1i1ii
def eevVeVeeveveeve ( url , iconimage ) :
 I1IiIiiIII = eevVevVVVevVee ( url )
 I1II1I11I1I = re . compile ( '^#.+?:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( I1IiIiiIII )
 VeVVeve = [ ]
 for i1II1 , iI111I11I1I1 , url in I1II1I11I1I :
  i11i1 = { "params" : i1II1 , "name" : iI111I11I1I1 , "url" : url }
  VeVVeve . append ( i11i1 )
 list = [ ]
 for VVVVeeevVe in VeVVeve :
  i11i1 = { "name" : VVVVeeevVe [ "name" ] , "url" : VVVVeeevVe [ "url" ] }
  I1II1I11I1I = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( VVVVeeevVe [ "params" ] )
  for IiiiiI1i1Iii , eeeveveVeve in I1II1I11I1I :
   i11i1 [ IiiiiI1i1Iii . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = eeeveveVeve . strip ( )
  list . append ( i11i1 )
 for VVVVeeevVe in list :
  if '.ts' in VVVVeeevVe [ "url" ] : i1I1iI ( VVVVeeevVe [ "name" ] , VVVVeeevVe [ "url" ] , 2 , iconimage , eevVeVeVVevev )
  else : Ii1I1IIii1II ( VVVVeeevVe [ "name" ] , VVVVeeevVe [ "url" ] , 2 , iconimage , eevVeVeVVevev )
  if 31 - 31: VevVeeeevev
def VeeevVVeveVVii11i1 ( name , url , iconimage , fanart , item ) :
 I1ii11iIi11i = ''
 i1VVVeveveveveV = re . compile ( '<link>(.+?)</link>' ) . findall ( item )
 ii11iIi1I = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( item )
 for name , iI1i111I1Ii , iconimage , fanart in ii11iIi1I :
  if 'youtube.com/playlist?' in iI1i111I1Ii :
   VeVVevevev = iI1i111I1Ii . split ( 'list=' ) [ 1 ]
   eVVeVev ( name , iI1i111I1Ii , i11i1ii1I , iconimage , fanart , description = VeVVevevev )
 if len ( i1VVVeveveveveV ) == 1 :
  ii11iIi1I = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( item )
  for name , url , iconimage , fanart in ii11iIi1I :
   try :
    I1ii11iIi11i = II ( url )
    eevVVeveeveeveve = url . split ( '/' ) [ 2 ] . replace ( 'www.' , '' )
    if 'SportsDevil' in url : eevVVeveeveeveve = ''
   except : pass
   if '.ts' in url : Ii1I1IIii1II ( name , url , 16 , iconimage , fanart , description = '' )
   if '<meta>' in item :
    eeeevevVVVeeV = re . compile ( '<meta>(.+?)</meta>' ) . findall ( item ) [ 0 ]
    eVev ( name + I1ii11iIi11i , url , 2 , iconimage , 10 , eeeevevVVVeeV , isFolder = False )
   else :
    Ii1I1IIii1II ( name + I1ii11iIi11i , url , 2 , iconimage , fanart )
 elif len ( i1VVVeveveveveV ) > 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
  if '.ts' in url : Ii1I1IIii1II ( name , url , 16 , iconimage , fanart , description = '' )
  if '<meta>' in item :
   eeeevevVVVeeV = re . compile ( '<meta>(.+?)</meta>' ) . findall ( item ) [ 0 ]
   eVev ( name , url , 3 , iconimage , len ( i1VVVeveveveveV ) , eeeevevVVVeeV , isFolder = True )
  else :
   eVVeVev ( name , url , 3 , iconimage , fanart )
   if 100 - 100: i1iIii1Ii1II / VeVeeev / II1iI
   if 78 - 78: VVVeveeve - VevVeeveVeve / i111I
def eee ( name , url , iconimage , fanart , item ) :
 i1VVVeveveveveV = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( item )
 I11IIIi = re . compile ( '<link>(.+?)</link>' ) . findall ( item )
 if len ( i1VVVeveveveveV ) + len ( I11IIIi ) == 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( item ) [ 0 ]
  url = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + url
  i1I1iI ( name , url , 16 , iconimage , fanart )
 elif len ( i1VVVeveveveveV ) + len ( I11IIIi ) > 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  eVVeVev ( name , url , 3 , iconimage , fanart )
  if 15 - 15: II1iI * eeveVev
def eeeveeeeeVev ( link ) :
 if eevVVV == '' :
  VevVeeVeeve = xbmcgui . Dialog ( )
  i1II1i = VevVeeVeeve . yesno ( 'Adult Content' , 'You have found the goodies ;)' , '' , 'Please set a password to prevent accidental access' , 'Cancel' , 'OK' )
  if i1II1i == 1 :
   VVeeveevVevV = xbmc . Keyboard ( '' , 'Set Password' )
   VVeeveevVevV . doModal ( )
   if ( VVeeveevVevV . isConfirmed ( ) ) :
    eev = VVeeveevVevV . getText ( )
    i1iII1IiiIiI1 . setSetting ( 'password' , eev )
  else : quit ( )
 elif eevVVV <> '' :
  VevVeeVeeve = xbmcgui . Dialog ( )
  i1II1i = VevVeeVeeve . yesno ( 'Adult Content' , 'Please enter the password you set!' , 'to continue' , 'dirty git' , 'Cancel' , 'OK' )
  if i1II1i == 1 :
   VVeeveevVevV = xbmc . Keyboard ( '' , 'Enter Password' )
   VVeeveevVevV . doModal ( )
   if ( VVeeveevVevV . isConfirmed ( ) ) :
    eev = VVeeveevVevV . getText ( )
   if eev <> eevVVV :
    quit ( )
  else : quit ( )
  if 95 - 95: eeveVev % i1IIi * i11iIiiIii % VVVeveeve - i1iIii1Ii1II
def VVeVeVe ( name , url , iconimage ) :
 eeveveveeeeVeve = ''
 eeVeeevV = VeeVev ( name )
 i1iII1IiiIiI1 . setSetting ( 'tv' , eeVeeevV )
 I1IiIiiIII = iI11 ( url )
 iI1i11 = re . compile ( '<title>.*?' + re . escape ( name ) + '.*?</title>(.+?)</item>' , re . DOTALL ) . findall ( I1IiIiiIII ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iI1i11 ) [ 0 ]
 i1VVVeveveveveV = [ ]
 if '<link>' in iI1i11 :
  VeVVeeeVVevV = re . compile ( '<link>(.+?)</link>' ) . findall ( iI1i11 )
  for eeeevevVee in VeVVeeeVVevV :
   i1VVVeveveveveV . append ( eeeevevVee )
 if '<sportsdevil>' in iI1i11 :
  VeeveevVevev = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( iI1i11 )
  for ii1 in VeeveevVevev :
   ii1 = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + ii1
   i1VVVeveveveveV . append ( ii1 )
 Veevev = 1
 for I1IiIiiIII in i1VVVeveveveveV :
  if '(' in I1IiIiiIII :
   I1IiIiiIII = I1IiIiiIII . split ( '(' )
   eeveveveeeeVeve = I1IiIiiIII [ 1 ] . replace ( ')' , '' )
   I1IiIiiIII = I1IiIiiIII [ 0 ]
  I1ii11iIi11i = II ( I1IiIiiIII )
  eevVVeveeveeveve = I1IiIiiIII . split ( '/' ) [ 2 ] . replace ( 'www.' , '' )
  if eeveveveeeeVeve <> '' : name = "Link " + str ( Veevev ) + ' | ' + eeveveveeeeVeve + I1ii11iIi11i
  else : name = "Link " + str ( Veevev ) + ' | ' + eevVVeveeveeveve + I1ii11iIi11i
  Veevev = Veevev + 1
  eVev ( name , I1IiIiiIII , 2 , iconimage , 10 , '' , isFolder = False , description = i1iII1IiiIiI1 . getSetting ( 'tv' ) )
  if 39 - 39: I11i1i11i1I / eVVee . VevVeeveVeve % Vev * eeIiII1I1i1i1ii + eVeve
def VVeeevVev ( name , url , iconimage , fanart , item ) :
 ii11iIi1I = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( item )
 for name , url , iconimage , fanart in ii11iIi1I :
  if 'youtube.com/channel/' in url :
   VeVVevevev = url . split ( 'channel/' ) [ 1 ]
   eVVeVev ( name , url , i11i1ii1I , iconimage , fanart , description = VeVVevevev )
  elif 'youtube.com/user/' in url :
   VeVVevevev = url . split ( 'user/' ) [ 1 ]
   eVVeVev ( name , url , i11i1ii1I , iconimage , fanart , description = VeVVevevev )
  elif 'youtube.com/playlist?' in url :
   VeVVevevev = url . split ( 'list=' ) [ 1 ]
   eVVeVev ( name , url , i11i1ii1I , iconimage , fanart , description = VeVVevevev )
  elif 'plugin://' in url :
   VeveeevV = HTMLParser ( )
   url = VeveeevV . unescape ( url )
   eVVeVev ( name , url , i11i1ii1I , iconimage , fanart )
  else :
   eVVeVev ( name , url , 1 , iconimage , fanart )
   if 36 - 36: VevVeeeevev + Vev - I11i1i11i1I - Vev % i1IIi11111i . i1iIii1Ii1II
def eeeiiI ( ) :
 VVeeveevVevV = xbmc . Keyboard ( '' , '[B][COLOR red]S[/COLOR][COLOR white]earch[/COLOR][/B] [B][COLOR red]E[/COLOR][COLOR white]volve[/COLOR][/B]' )
 VVeeveevVevV . doModal ( )
 if ( VVeeveevVevV . isConfirmed ( ) ) :
  VeVVevevev = VVeeveevVevV . getText ( )
  VeVVevevev = VeVVevevev . upper ( )
 else : quit ( )
 I1IiIiiIII = iI11 ( 'http://pastebin.com/TqpecnXw' )
 eVeevevVeveeeveveev = re . compile ( '<link>(.+?)</link>' ) . findall ( I1IiIiiIII )
 for VVeeVevVVee in eVeevevVeveeeveveev :
  try :
   I1IiIiiIII = iI11 ( VVeeVevVVee )
   ii = re . compile ( '<item>(.+?)</item>' ) . findall ( I1IiIiiIII )
   for i1iIIi1 in ii :
    iII111ii = re . compile ( '<title>(.+?)</title>' ) . findall ( i1iIIi1 )
    for iIIIi1 in iII111ii :
     iIIIi1 = iIIIi1 . upper ( )
     if VeVVevevev in iIIIi1 :
      II11iiii1Ii ( iI111I11I1I1 , VVeeVevVVee , iIii1 , eevVeVeVVevev , i1iIIi1 )
  except : pass
  if 56 - 56: VVVeveeve . II1iI . eVeve
def ii111I ( url ) :
 eVVevevV = "ShowPicture(%s)" % url
 xbmc . executebuiltin ( eVVevevV )
 if 17 - 17: eVeve . Vev + eeveVev
def iiIiii1iI1i ( name , url , iconimage , description ) :
 if description : name = description
 try :
  if 'plugin://plugin.video.SportsDevil/' in url :
   I1ii1ii11i1I ( name , url , iconimage )
  elif '.ts' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name=' + name + '&amp;url=' + url
   url = url . replace ( '|' , '' )
   I1ii1ii11i1I ( name , url , iconimage )
  elif urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
   url = urlresolver . HostedMediaFile ( url ) . resolve ( )
   eevVeVV ( name , url , iconimage )
  elif liveresolver . isValid ( url ) == True :
   url = liveresolver . resolve ( url )
   eevVeVV ( name , url , iconimage )
  else : eevVeVV ( name , url , iconimage )
 except :
  VevVevVeevev ( eVeVeveve ( 'Evolve' ) , 'Stream Unavailable' , '3000' , VevV )
  if 100 - 100: VevVeeveVeve + VevVeeeevev * VevVeeveVeve
def III1ii1iII ( url ) :
 if urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
  url = urlresolver . HostedMediaFile ( url ) . resolve ( )
 xbmc . Player ( ) . play ( url )
 if 80 - 80: VevVeeveVeve * Vev - I11i1i11i1I
def eevVeVV ( name , url , iconimage ) :
 eeevevVevevVe = True
 IIIII1II = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage ) ; IIIII1II . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 eeevevVevevVe = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = url , listitem = IIIII1II )
 IIIII1II . setPath ( url )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IIIII1II )
 if 35 - 35: iIii1I11I1II1
def I1ii1ii11i1I ( name , url , iconimage ) :
 xbmc . executebuiltin ( 'Dialog.Close(all,True)' )
 eeevevVevevVe = True
 IIIII1II = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage ) ; IIIII1II . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 eeevevVevevVe = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = url , listitem = IIIII1II )
 xbmc . Player ( ) . play ( url , IIIII1II , False )
 if 42 - 42: VeVeeev . eVeve . i1IIi + i111I + VevVeeeevev + eVeve
def I1I ( url ) :
 xbmc . executebuiltin ( "PlayMedia(%s)" % url )
 if 68 - 68: eVVee
def iI11 ( url ) :
 iI1 = urllib2 . Request ( url )
 iI1 . add_header ( 'User-Agent' , 'mat' )
 iIIi = urllib2 . urlopen ( iI1 )
 I1IiIiiIII = iIIi . read ( )
 iIIi . close ( )
 I1IiIiiIII = I1IiIiiIII . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 if '{' in I1IiIiiIII :
  eVVevevV = I1IiIiiIII [ : : - 1 ]
  eVVevevV = eVVevevV . replace ( '}' , '' ) . replace ( '{' , '' ) . replace ( ',' , '' ) . replace ( ']' , '' ) . replace ( '[' , '' )
  eVVevevV = eVVevevV + '=='
  I1IiIiiIII = eVVevevV . decode ( 'base64' )
 if url <> Iii1ii1II11i : I1IiIiiIII = I1IiIiiIII . replace ( '\n' , '' ) . replace ( '\r' , '' )
 print I1IiIiiIII
 return I1IiIiiIII
 if 62 - 62: VVVeveeve - i1IIi11111i
def eevVevVVVevVee ( url ) :
 iI1 = urllib2 . Request ( url )
 iI1 . add_header ( 'User-Agent' , 'mat' )
 iIIi = urllib2 . urlopen ( iI1 )
 I1IiIiiIII = iIIi . read ( )
 iIIi . close ( )
 return I1IiIiiIII
 if 21 - 21: Vev % eVVVeeveevV . eVeve / I1II1 + eVVVeeveevV
def IIiIi1iI ( url ) :
 iI1 = urllib2 . Request ( url )
 iI1 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 iIIi = urllib2 . urlopen ( iI1 )
 I1IiIiiIII = iIIi . read ( )
 iIIi . close ( )
 I1IiIiiIII = I1IiIiiIII . replace ( '\n' , '' ) . replace ( '\r' , '' )
 return I1IiIiiIII
 if 53 - 53: i1iIii1Ii1II - eVeve - i1iIii1Ii1II * eeIiII1I1i1i1ii
 if 71 - 71: Vev - iIii1I11I1II1
def i1II ( ) :
 iI1I = [ ]
 VeeVeVe = sys . argv [ 2 ]
 if len ( VeeVeVe ) >= 2 :
  i1II1 = sys . argv [ 2 ]
  III1I1Iii1iiI = i1II1 . replace ( '?' , '' )
  if ( i1II1 [ len ( i1II1 ) - 1 ] == '/' ) :
   i1II1 = i1II1 [ 0 : len ( i1II1 ) - 2 ]
  i1Iii11I1i = III1I1Iii1iiI . split ( '&' )
  iI1I = { }
  for Veevev in range ( len ( i1Iii11I1i ) ) :
   VeeveveevVVevVeveve = { }
   VeeveveevVVevVeveve = i1Iii11I1i [ Veevev ] . split ( '=' )
   if ( len ( VeeveveevVVevVeveve ) ) == 2 :
    iI1I [ VeeveveevVVevVeveve [ 0 ] ] = VeeveveevVVevVeveve [ 1 ]
 return iI1I
 if 82 - 82: i1IIi11111i + VeeeeeeeVV - i1IIi . i1IIi
def VevVevVeevev ( title , message , ms , nart ) :
 xbmc . executebuiltin ( "XBMC.notification(" + title + "," + message + "," + ms + "," + nart + ")" )
 if 6 - 6: VevVeeveVeve / i1IIi11111i / I1II1
def VeeVev ( string ) :
 I1i11111i1i11 = re . compile ( '(\[.+?\])' ) . findall ( string )
 for VVeVVVev in I1i11111i1i11 : string = string . replace ( VVeVVVev , '' )
 return string
 if 10 - 10: VeVeeev / eVVee + i11iIiiIii / I11i1i11i1I
def eVeVeveve ( string ) :
 string = string . split ( ' ' )
 VVVeVeV = ''
 for iIIIII1ii1I in string :
  Ii1i1iI = '[B][COLOR red]' + iIIIII1ii1I [ 0 ] . upper ( ) + '[/COLOR][COLOR white]' + iIIIII1ii1I [ 1 : ] + '[/COLOR][/B] '
  VVVeVeV = VVVeVeV + Ii1i1iI
 return VVVeVeV
 if 16 - 16: VevVeeeevev / VVVeveeve / VeeeeeeeVV * eVeve + i1IIi % VevVeeeevev
def eVev ( name , url , mode , iconimage , itemcount , metatype , isFolder = False , description = '' ) :
 if isFolder == True : i1iII1IiiIiI1 . setSetting ( 'favtype' , 'folder' )
 else : i1iII1IiiIiI1 . setSetting ( 'favtype' , 'link' )
 if iIiiiI == 'true' :
  eeeeveevev = name
  name = VeeVev ( name )
  eeV = ""
  eeveevev = ""
  IIi = [ ]
  eVeVeveveeevV = eval ( base64 . b64decode ( 'bWV0YWhhbmRsZXJzLk1ldGFEYXRhKHRtZGJfYXBpX2tleT0iZDk1NWQ4ZjAyYTNmMjQ4MGE1MTg4MWZlNGM5NmYxMGUiKQ==' ) )
  Ii11Ii1I = { }
  if metatype == 'movie' :
   VVVevevV = name . partition ( '(' )
   if len ( VVVevevV ) > 0 :
    eeV = VVVevevV [ 0 ]
    eeveevev = VVVevevV [ 2 ] . partition ( ')' )
   if len ( eeveevev ) > 0 :
    eeveevev = eeveevev [ 0 ]
   Ii11Ii1I = eVeVeveveeevV . get_meta ( 'movie' , name = eeV , year = eeveevev )
   if not Ii11Ii1I [ 'trailer' ] == '' : IIi . append ( ( eVeVeveve ( 'Play Trailer' ) , 'XBMC.RunPlugin(%s)' % ee . build_plugin_url ( { 'mode' : 11 , 'url' : Ii11Ii1I [ 'trailer' ] } ) ) )
  elif metatype == 'tvep' :
   iIIIi1 = i1iII1IiiIiI1 . getSetting ( 'tv' )
   if '<>' in url :
    print url
    i1 = url . split ( '<>' ) [ 0 ]
    eVevVe = url . split ( '<>' ) [ 1 ]
    eVVeeevVe = url . split ( '<>' ) [ 2 ]
    eevevVVevevVeV = url . split ( '<>' ) [ 3 ]
    VVVVevVVeVevVev = url . split ( '<>' ) [ 4 ]
    VevVeeveveveeVevev = url . split ( '<>' ) [ 5 ]
    Ii11Ii1I = eVeVeveveeevV . get_episode_meta ( eVevVe , imdb_id = i1 , season = eVVeeevVe , episode = eevevVVevevVeV , air_date = '' , episode_title = '' , overlay = '' )
   else :
    IiiiI = re . compile ( 'Season (.+?) Episode (.+?)\)' ) . findall ( name )
    for VevevVeVVeveeev , eVV in IiiiI :
     Ii11Ii1I = eVeVeveveeevV . get_episode_meta ( iIIIi1 , imdb_id = '' , season = VevevVeVVeveeev , episode = eVV , air_date = '' , episode_title = '' , overlay = '' )
  try :
   if Ii11Ii1I [ 'cover_url' ] == '' : iconimage = iconimage
   else : iconimage = Ii11Ii1I [ 'cover_url' ]
  except : pass
  VeveevVVeveveveveee = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( eevVeVeVVevev ) + "&iconimage=" + urllib . quote_plus ( iconimage )
  eeevevVevevVe = True
  IIIII1II = xbmcgui . ListItem ( eeeeveevev , iconImage = iconimage , thumbnailImage = iconimage )
  IIIII1II . setInfo ( type = "Video" , infoLabels = Ii11Ii1I )
  IIIII1II . setProperty ( "IsPlayable" , "true" )
  IIIII1II . addContextMenuItems ( IIi , replaceItems = False )
  if not Ii11Ii1I . get ( 'backdrop_url' , '' ) == '' : IIIII1II . setProperty ( 'fanart_image' , Ii11Ii1I [ 'backdrop_url' ] )
  else : IIIII1II . setProperty ( 'fanart_image' , eevVeVeVVevev )
  iIIII1iIIii = i1iII1IiiIiI1 . getSetting ( 'favlist' )
  eVVVeveveeveveve = [ ]
  eVVVeveveeveveve . append ( ( eVeVeveve ( 'Stream Information' ) , 'XBMC.Action(Info)' ) )
  if iIIII1iIIii == 'yes' : eVVVeveveeveveve . append ( ( '[COLOR white]Remove from Evolve Favourites[/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
  else : eVVVeveveeveveve . append ( ( '[COLOR white]Add to Evolve Favourites[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
  IIIII1II . addContextMenuItems ( eVVVeveveeveveve , replaceItems = False )
  eeevevVevevVe = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = VeveevVVeveveveveee , listitem = IIIII1II , isFolder = isFolder , totalItems = itemcount )
  return eeevevVevevVe
 else :
  if isFolder :
   eVVeVev ( name , url , mode , iconimage , eevVeVeVVevev , description = '' )
  else :
   Ii1I1IIii1II ( name , url , mode , iconimage , eevVeVeVVevev , description = '' )
   if 9 - 9: i1iIii1Ii1II + i1IIi11111i / i1IIi11111i
def eVVeVev ( name , url , mode , iconimage , fanart , description = '' ) :
 i1iII1IiiIiI1 . setSetting ( 'favtype' , 'folder' )
 VeveevVVeveveveveee = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 eeevevVevevVe = True
 IIIII1II = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 IIIII1II . setInfo ( type = "Video" , infoLabels = { "Title" : name , 'plot' : description } )
 IIIII1II . setProperty ( 'fanart_image' , fanart )
 if 'youtube.com/channel/' in url :
  VeveevVVeveveveveee = 'plugin://plugin.video.youtube/channel/' + description + '/'
 if 'youtube.com/user/' in url :
  VeveevVVeveveveveee = 'plugin://plugin.video.youtube/user/' + description + '/'
 if 'youtube.com/playlist?' in url :
  VeveevVVeveveveveee = 'plugin://plugin.video.youtube/playlist/' + description + '/'
 if 'plugin://' in url :
  VeveevVVeveveveveee = url
 eVVVeveveeveveve = [ ]
 iIIII1iIIii = i1iII1IiiIiI1 . getSetting ( 'favlist' )
 if iIIII1iIIii == 'yes' : eVVVeveveeveveve . append ( ( '[COLOR white]Remove from Evolve Favourites[/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 else : eVVVeveveeveveve . append ( ( '[COLOR white]Add to Evolve Favourites[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 IIIII1II . addContextMenuItems ( eVVVeveveeveveve , replaceItems = False )
 eeevevVevevVe = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = VeveevVVeveveveveee , listitem = IIIII1II , isFolder = True )
 return eeevevVevevVe
 if 12 - 12: VeeeeeeeVV % VevVeeveVeve * i1IIi11111i % iIii1I11I1II1 / I11i1i11i1I
def i1I1iI ( name , url , mode , iconimage , fanart , description = '' ) :
 i1iII1IiiIiI1 . setSetting ( 'favtype' , 'link' )
 VeveevVVeveveveveee = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 eeevevVevevVe = True
 IIIII1II = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 IIIII1II . setProperty ( 'fanart_image' , fanart )
 eVVVeveveeveveve = [ ]
 iIIII1iIIii = i1iII1IiiIiI1 . getSetting ( 'favlist' )
 if iIIII1iIIii == 'yes' : eVVVeveveeveveve . append ( ( '[COLOR white]Remove from Evolve Favourites[/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 else : eVVVeveveeveveve . append ( ( '[COLOR white]Add to Evolve Favourites[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 IIIII1II . addContextMenuItems ( eVVVeveveeveveve , replaceItems = False )
 eeevevVevevVe = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = VeveevVVeveveveveee , listitem = IIIII1II , isFolder = False )
 return eeevevVevevVe
 if 27 - 27: i11iIiiIii % I1II1 % i1IIi11111i . Vev - VVVeveeve + i111I
def Ii1I1IIii1II ( name , url , mode , iconimage , fanart , description = '' ) :
 i1iII1IiiIiI1 . setSetting ( 'favtype' , 'link' )
 VeveevVVeveveveveee = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 eeevevVevevVe = True
 IIIII1II = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 IIIII1II . setProperty ( 'fanart_image' , fanart )
 IIIII1II . setProperty ( "IsPlayable" , "true" )
 eVVVeveveeveveve = [ ]
 iIIII1iIIii = i1iII1IiiIiI1 . getSetting ( 'favlist' )
 if iIIII1iIIii == 'yes' : eVVVeveveeveveve . append ( ( '[COLOR white]Remove from Evolve Favourites[/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 else : eVVVeveveeveveve . append ( ( '[COLOR white]Add to Evolve Favourites[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 IIIII1II . addContextMenuItems ( eVVVeveveeveveve , replaceItems = False )
 eeevevVevevVe = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = VeveevVVeveveveveee , listitem = IIIII1II , isFolder = False )
 return eeevevVevevVe
 if 57 - 57: iIii1I11I1II1 / i1IIi11111i - i1IIi
def Ii1I ( url , name ) :
 eeVVeevevVevevVe = eevVevVVVevVee ( url )
 if len ( eeVVeevevVevevVe ) > 1 :
  VeeeveVeeeev = iI111iI
  eVVVeeevev = os . path . join ( os . path . join ( VeeeveVeeeev , '' ) , name + '.txt' )
  if not os . path . exists ( eVVVeeevev ) :
   file ( eVVVeeevev , 'w' ) . close ( )
  IiII1 = open ( eVVVeeevev )
  I1iIi1iIiiIiI = IiII1 . read ( )
  if I1iIi1iIiiIiI == eeVVeevevVevevVe : pass
  else :
   II1iIVeveeveevevVVevevevev ( '[B][COLOR red]E[/COLOR][COLOR white]volve[/COLOR][/B] [B][COLOR red]I[/COLOR][COLOR white]nformation[/COLOR][/B]' , eeVVeevevVevevVe )
   iiIiIIIiiI = open ( eVVVeeevev , "w" )
   iiIiIIIiiI . write ( eeVVeevevVevevVe )
   iiIiIIIiiI . close ( )
   if 47 - 47: I11i1i11i1I + VeVeeev / i1IIi % i11iIiiIii
def II1iIVeveeveevevVVevevevev ( heading , text ) :
 id = 10147
 xbmc . executebuiltin ( 'ActivateWindow(%d)' % id )
 xbmc . sleep ( 500 )
 i111iI = xbmcgui . Window ( id )
 VVe = 50
 while ( VVe > 0 ) :
  try :
   xbmc . sleep ( 10 )
   VVe -= 1
   i111iI . getControl ( 1 ) . setLabel ( heading )
   i111iI . getControl ( 5 ) . setText ( text )
   return
  except :
   pass
   if 50 - 50: eVVee
def eevVevVeveeeeveVV ( name ) :
 global Icon
 global Next
 global Previous
 global window
 global Quit
 global images
 eVVVeeevev = os . path . join ( os . path . join ( iI111iI , '' ) , name + '.txt' )
 IiII1 = open ( eVVVeeevev )
 I1iIi1iIiiIiI = IiII1 . read ( )
 images = re . compile ( '<image>(.+?)</image>' ) . findall ( I1iIi1iIiiIiI )
 i1iII1IiiIiI1 . setSetting ( 'pos' , '0' )
 window = pyxbmct . AddonDialogWindow ( '' )
 eeevevev = '/resources/art'
 iiVeV = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + eevVVevev + eeevevev , 'next_focus.png' ) )
 Iiiiii111i1ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + eevVVevev + eeevevev , 'next1.png' ) )
 i1i1iII1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + eevVVevev + eeevevev , 'previous_focus.png' ) )
 iii11i1IIII = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + eevVVevev + eeevevev , 'previous.png' ) )
 Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + eevVVevev + eeevevev , 'close_focus.png' ) )
 eevev = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + eevVVevev + eeevevev , 'close.png' ) )
 iiI1Ii1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + eevVVevev + eeevevev , 'main-bg1.png' ) )
 window . setGeometry ( 1300 , 720 , 100 , 50 )
 ii1i = pyxbmct . Image ( iiI1Ii1 )
 window . placeControl ( ii1i , - 10 , - 10 , 130 , 70 )
 i11I1IiII1i1i = '0xFF000000'
 Previous = pyxbmct . Button ( '' , focusTexture = i1i1iII1 , noFocusTexture = iii11i1IIII , textColor = i11I1IiII1i1i , focusedColor = i11I1IiII1i1i )
 Next = pyxbmct . Button ( '' , focusTexture = iiVeV , noFocusTexture = Iiiiii111i1ii , textColor = i11I1IiII1i1i , focusedColor = i11I1IiII1i1i )
 Quit = pyxbmct . Button ( '' , focusTexture = Ii , noFocusTexture = eevev , textColor = i11I1IiII1i1i , focusedColor = i11I1IiII1i1i )
 Icon = pyxbmct . Image ( images [ 0 ] , aspectRatio = 2 )
 window . placeControl ( Previous , 102 , 1 , 10 , 10 )
 window . placeControl ( Next , 102 , 40 , 10 , 10 )
 window . placeControl ( Quit , 102 , 21 , 10 , 10 )
 window . placeControl ( Icon , 0 , 0 , 100 , 50 )
 Previous . controlRight ( Next )
 Previous . controlUp ( Quit )
 window . connect ( Previous , eVVeeiII1111III1I )
 window . connect ( Next , ii11i )
 Previous . setVisible ( False )
 window . setFocus ( Quit )
 Previous . controlRight ( Quit )
 Quit . controlLeft ( Previous )
 Quit . controlRight ( Next )
 Next . controlLeft ( Quit )
 window . connect ( Quit , window . close )
 window . doModal ( )
 del window
 if 100 - 100: eVVee % iIii1I11I1II1 * I1II1 - eeIiII1I1i1i1ii
def ii11i ( ) :
 eeevevVeveveVeveveve = int ( i1iII1IiiIiI1 . getSetting ( 'pos' ) )
 VVeevevVeV = int ( eeevevVeveveVeveveve ) + 1
 i1iII1IiiIiI1 . setSetting ( 'pos' , str ( VVeevevVeV ) )
 iIi1 = len ( images )
 Icon . setImage ( images [ int ( VVeevevVeV ) ] )
 Previous . setVisible ( True )
 if int ( VVeevevVeV ) == int ( iIi1 ) - 1 :
  Next . setVisible ( False )
  if 21 - 21: i1IIi11111i
def eVVeeiII1111III1I ( ) :
 eeevevVeveveVeveveve = int ( i1iII1IiiIiI1 . getSetting ( 'pos' ) )
 VeVevev = int ( eeevevVeveveVeveveve ) - 1
 i1iII1IiiIiI1 . setSetting ( 'pos' , str ( VeVevev ) )
 Icon . setImage ( images [ int ( VeVevev ) ] )
 Next . setVisible ( True )
 if int ( VeVevev ) == 0 :
  Previous . setVisible ( False )
  if 85 - 85: VVVeveeve * VVVeveeve * eVeve . VeeeeeeeVV . I11i1i11i1I * eVVee
def eeveveveVeeeveevevev ( url , fanart ) :
 i1iII1IiiIiI1 . setSetting ( 'favlist' , 'yes' )
 IiI11iI1i1i1i = None
 file = open ( IiII , 'r' )
 IiI11iI1i1i1i = file . read ( ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 iII111ii = re . compile ( "<item>(.+?)</item>" , re . DOTALL ) . findall ( IiI11iI1i1i1i )
 for i1iIIi1 in iII111ii :
  II11iiii1Ii ( iI111I11I1I1 , url , VevV , fanart , i1iIIi1 )
 i1iII1IiiIiI1 . setSetting ( 'favlist' , 'no' )
 if 89 - 89: i1IIi11111i
def Veeeeee ( name , url , iconimage , fanart ) :
 I1IIIiI1I1ii1 = i1iII1IiiIiI1 . getSetting ( 'favtype' )
 url = url . replace ( ' ' , '%20' )
 iconimage = iconimage . replace ( ' ' , '%20' )
 if '<>' in url :
  i1 = url . split ( '<>' ) [ 0 ]
  eVVeeevVe = url . split ( '<>' ) [ 1 ]
  eevevVVevevVeV = url . split ( '<>' ) [ 2 ]
  VVVVevVVeVevVev = url . split ( '<>' ) [ 3 ]
  VevVeeveveveeVevev = url . split ( '<>' ) [ 4 ]
  eVVevevV = '<FAV><item>\n<title>' + name + '</title>\n<meta>tvep</meta>\n<nan>tvshow</nan>\n<showyear>' + VVVVevVVeVevVev + '</showyear>\n<imdb>' + i1 + '</imdb>\n<season>' + eVVeeevVe + '</season>\n<episode>' + eevevVVevevVeV + '</episode>\n<episodeyear>' + VevVeeveveveeVevev + '</episodeyear>\n<thumbnail>' + iconimage + '</thumbnail>\n<fanart>' + fanart + '</fanart></item></FAV>\n'
 elif len ( url ) == 9 :
  eVVevevV = '<FAV><item>\n<title>' + name + '</title>\n<meta>movie</meta>\n<nan>movie</nan>\n<imdb>' + url + '</imdb>\n' + '<thumbnail>' + iconimage + '</thumbnail>\n<fanart>' + fanart + '</fanart></item></FAV>\n'
 else :
  eVVevevV = '<FAV><item>\n<title>' + name + '</title>\n<' + I1IIIiI1I1ii1 + '>' + url + '</' + I1IIIiI1I1ii1 + '>\n' + '<thumbnail>' + iconimage + '</thumbnail>\n<fanart>' + fanart + '</fanart></item></FAV>\n'
 iI1Ii11111iIi = open ( IiII , 'a' )
 iI1Ii11111iIi . write ( eVVevevV )
 iI1Ii11111iIi . close ( )
 if 30 - 30: Vev * VeeeeeeeVV
def I1iIIIi1 ( name , url , iconimage ) :
 print name
 IiI11iI1i1i1i = None
 file = open ( IiII , 'r' )
 IiI11iI1i1i1i = file . read ( )
 Iii = ''
 iII111ii = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( IiI11iI1i1i1i )
 for ii11iIi1I in iII111ii :
  eVVevevV = '\n<FAV><item>\n' + ii11iIi1I + '</item>\n'
  if name in ii11iIi1I :
   print 'xxxxxxxxxxxxxxxxx'
   eVVevevV = eVVevevV . replace ( 'item' , ' ' )
  Iii = Iii + eVVevevV
 file = open ( IiII , 'w' )
 file . truncate ( )
 file . write ( Iii )
 file . close ( )
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 19 - 19: i1IIi11111i % I1II1 / i11iIiiIii / eeIiII1I1i1i1ii - VeeeeeeeVV
def II ( url ) :
 try :
  eevVVeveeveeveve = url . split ( '/' ) [ 2 ] . replace ( 'www.' , '' )
  file = open ( I1ii11iIi11i , 'r' )
  iIIii = file . read ( )
  if eevVVeveeveeveve in iIIii : return '[COLOR springgreen] (RD)[/COLOR]'
  else : return ''
 except : return ''
 if 18 - 18: eeIiII1I1i1i1ii . eVeve
def iiIi1IIiI ( ) :
 xbmcaddon . Addon ( 'script.module.nanscrapers' ) . openSettings ( )
 if 23 - 23: I11i1i11i1I . VevVeeeevev
def i1II11II ( ) :
 xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
 if 87 - 87: i111I * VeVeeev . i1IIi11111i
def VevVeeveeveveveV ( ) :
 xbmcaddon . Addon ( 'script.module.metahandler' ) . openSettings ( )
 if 99 - 99: i1iIii1Ii1II * I1II1 * VeVeeev
def ii11i1iIII ( link ) :
 try :
  eVeeVev = re . compile ( '<layouttype>(.+?)</layouttype>' ) . findall ( link ) [ 0 ]
  if eVeeVev == 'thumbnail' : xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
  else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 except : pass
 if 79 - 79: eeveVev - iIii1I11I1II1 + I11i1i11i1I - VeVeeev
 if 93 - 93: I1II1 . eVeve - VVVeveeve + i111I
i1II1 = i1II ( ) ; VVeeVevVVee = None ; iI111I11I1I1 = None ; i11i1ii1I = None ; eeVeve = None ; iIii1 = None ; eevevev = None
try : eeVeve = urllib . unquote_plus ( i1II1 [ "site" ] )
except : pass
try : VVeeVevVVee = urllib . unquote_plus ( i1II1 [ "url" ] )
except : pass
try : iI111I11I1I1 = urllib . unquote_plus ( i1II1 [ "name" ] )
except : pass
try : i11i1ii1I = int ( i1II1 [ "mode" ] )
except : pass
try : iIii1 = urllib . unquote_plus ( i1II1 [ "iconimage" ] )
except : pass
try : eevVeVeVVevev = urllib . unquote_plus ( i1II1 [ "fanart" ] )
except : pass
try : eevevev = str ( i1II1 [ "description" ] )
except : pass
if 3 - 3: I1II1 / VevVeeeevev + eVVVeeveevV . eVVee . eeveVev
if i11i1ii1I == None or VVeeVevVVee == None or len ( VVeeVevVVee ) < 1 : VeeevVVeveVV ( )
elif i11i1ii1I == 1 : I11I11i1I ( iI111I11I1I1 , VVeeVevVVee , iIii1 , eevVeVeVVevev )
elif i11i1ii1I == 2 : iiIiii1iI1i ( iI111I11I1I1 , VVeeVevVVee , iIii1 , eevevev )
elif i11i1ii1I == 3 : VVeVeVe ( iI111I11I1I1 , VVeeVevVVee , iIii1 )
elif i11i1ii1I == 4 : eevVeVV ( iI111I11I1I1 , VVeeVevVVee , iIii1 )
elif i11i1ii1I == 5 : eeeiiI ( )
elif i11i1ii1I == 6 : eevVeVeeveveeve ( VVeeVevVVee , iIii1 )
elif i11i1ii1I == 7 : ii111I ( VVeeVevVVee )
elif i11i1ii1I == 8 : eevVevVeveeeeveVV ( iI111I11I1I1 )
elif i11i1ii1I == 9 : VevVV ( iI111I11I1I1 , VVeeVevVVee )
elif i11i1ii1I == 10 : eVVevVeveveVevVee ( iI111I11I1I1 , VVeeVevVVee , iIii1 , eevVeVeVVevev )
elif i11i1ii1I == 11 : I1I ( VVeeVevVVee )
elif i11i1ii1I == 12 : i1II11II ( )
elif i11i1ii1I == 13 : VevVeeveeveveveV ( )
elif i11i1ii1I == 15 : SCRAPEMOVIE ( iI111I11I1I1 , VVeeVevVVee , iIii1 )
elif i11i1ii1I == 16 : I1ii1ii11i1I ( iI111I11I1I1 , VVeeVevVVee , iIii1 )
elif i11i1ii1I == 17 : iI1111iiii ( iI111I11I1I1 , VVeeVevVVee )
elif i11i1ii1I == 18 : eeeeeVeeeveee ( iI111I11I1I1 , VVeeVevVVee , iIii1 , eevVeVeVVevev )
elif i11i1ii1I == 19 : iIi1iIiii111 ( iI111I11I1I1 , VVeeVevVVee , iIii1 , eevVeVeVVevev )
if 83 - 83: i1iIii1Ii1II + VeeeeeeeVV
elif i11i1ii1I == 20 : Veeeeee ( iI111I11I1I1 , VVeeVevVVee , iIii1 , eevVeVeVVevev )
elif i11i1ii1I == 21 : I1iIIIi1 ( iI111I11I1I1 , VVeeVevVVee , iIii1 )
elif i11i1ii1I == 22 : eeveveveVeeeveevevev ( VVeeVevVVee , eevVeVeVVevev )
elif i11i1ii1I == 23 : DOIPLAYER ( iI111I11I1I1 , VVeeVevVVee , iIii1 , eevVeVeVVevev )
elif i11i1ii1I == 24 : eeeeevVev ( iI111I11I1I1 , VVeeVevVVee , iIii1 , eevVeVeVVevev )
elif i11i1ii1I == 25 : iiIi1IIiI ( )
if 22 - 22: I11i1i11i1I % eeIiII1I1i1i1ii * VeeeeeeeVV - VevVeeveVeve / iIii1I11I1II1
elif i11i1ii1I == 26 : iiIiIIi ( iI111I11I1I1 , VVeeVevVVee , iIii1 , eevVeVeVVevev )
elif i11i1ii1I == 27 : VeveevVe ( iI111I11I1I1 , VVeeVevVVee , iIii1 , eevVeVeVVevev )
elif i11i1ii1I == 28 : eeveV ( iI111I11I1I1 , VVeeVevVVee , iIii1 , eevVeVeVVevev )
elif i11i1ii1I == 29 : III1Iiii1I11 ( iI111I11I1I1 , VVeeVevVVee , iIii1 , eevVeVeVVevev )
elif i11i1ii1I == 30 : eeVVeeeeee ( iI111I11I1I1 , VVeeVevVVee , iIii1 , eevVeVeVVevev )
elif i11i1ii1I == 31 : eeveveeeVevVe ( iI111I11I1I1 , VVeeVevVVee , iIii1 , eevVeVeVVevev )
elif i11i1ii1I == 32 : eeveVevevevevev ( iI111I11I1I1 , VVeeVevVVee , iIii1 , eevVeVeVVevev )
elif i11i1ii1I == 33 : I1I1I ( VVeeVevVVee )
elif i11i1ii1I == 34 : iIiIIi1 ( iI111I11I1I1 , VVeeVevVVee , iIii1 , eevVeVeVVevev )
elif i11i1ii1I == 35 : I1I11i ( iI111I11I1I1 , VVeeVevVVee , iIii1 , eevVeVeVVevev )
if 86 - 86: VeeeeeeeVV . eeIiII1I1i1i1ii % i111I / i1IIi11111i * eeIiII1I1i1i1ii / VevVeeveVeve
if 64 - 64: i11iIiiIii
if 38 - 38: eVVVeeveevV / eVeve - eVVVeeveevV . i1IIi11111i
if 69 - 69: VeeeeeeeVV + II1iI
if 97 - 97: VevVeeeevev - eeveVev / I11i1i11i1I . i11iIiiIii % i1iIii1Ii1II * i1iIii1Ii1II
if 1 - 1: eVeve % eVVee
if 65 - 65: eVeve + i111I / VevVeeeevev
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
